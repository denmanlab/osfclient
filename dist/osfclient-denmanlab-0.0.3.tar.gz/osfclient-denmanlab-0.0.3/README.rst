.. image:: LOGO/osf-cli-logo-v1-small.png
   :alt: osfclient
   :align: right

*********
osfclient
*********

This is a small modification of the osfclient package to allow for use with the Denman Lab 
at the University of Colarado School of Medicince's experimental workflow

Main ``osfclient`` repo is `here <https://github.com/denmanlab/osfclient>`. 
