"""Client library for the Open Science Framework"""


from .api import OSF
from .__version__ import *


__all__ = ['OSF']
